function Footer() {
    return (
        <>
            <div
                style={{
                    backgroundColor: "#BBB",
                    textAlign: "center",
                    bottom: "0px",
                    position: "fixed",
                    width: "100vw",
                    lineHeight: "2",
                    fontSize: "20px",
                }}>
                Data based on NEXON Open API / Handong Global University
            </div>
        </>
    );
}

export default Footer;
